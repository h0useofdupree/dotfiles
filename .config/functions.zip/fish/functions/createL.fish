function createL
echo "Creating directory for $argv"
mkdir $argv
cd $argv
echo "Copying external file(s)..."
cp ~/Documents/LaTeX/latex-listings-powershell.tex .
echo "Done"
echo "Copying $USER's LaTeX preset..."
cp /home/juuls/Documents/LaTeX/default.tex ./$argv.tex
echo "Done"
echo "Named the default file '$argv'"
ls
end
